import { StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createDrawerNavigator } from '@react-navigation/drawer';

import Dashboard from '../view/Dashboard';
import Pickup from '../view/Pickup';
import Destination from '../view/Destination';
import Car from '../view/carSelection';
import RideHistory from '../view/RideHistory';
import RideHistoryDetail from '../view/RideHistoryDetail';

const Stack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();

function Navigator() {
  return (
    <NavigationContainer 
    drawerStyle={{
      backgroundColor: 'pink', // Set to light blue color
    }}>
      <Drawer.Navigator>
        <Drawer.Screen name="Dashboard" component={DashboardNavigator} />
        <Drawer.Screen name="Ride" component={HistoryNavigator} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

function DashboardNavigator() {
  return (
    <Stack.Navigator
    screenOptions={{
      headerStyle: {
        backgroundColor: "black", // Set to light green color
      },
      headerTintColor: '#fff', // Set text color of header buttons/icons
      headerTitleStyle: {
        fontWeight: 'bold', // Set text style of header title
      },
    }}>
      <Stack.Screen name="Home" component={Dashboard} />
      <Stack.Screen name="Pickup" component={Pickup} />
      <Stack.Screen name="Destination" component={Destination} />
      <Stack.Screen name="Car" component={Car} />
    </Stack.Navigator>
  );
}

function HistoryNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: 'lightgreen', // Set to light green color
        },
        headerTintColor: '#fff', // Set text color of header buttons/icons
        headerTitleStyle: {
          fontWeight: 'bold', // Set text style of header title
        },
      }}>
      <Stack.Screen name="Ride History" component={RideHistory} />
      <Stack.Screen name="RideHistoryDetail" component={RideHistoryDetail} />
    </Stack.Navigator>
  );
}

export default Navigator;
