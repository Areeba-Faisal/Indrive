import { StyleSheet, Text, View,Button } from 'react-native';


function RideHistory({navigation}) {
    return(
        <View>
            <Text>Ride History</Text>
            <Button title="ride History" onPress={() => navigation.navigate("RideHistoryDetail")}/>
        </View>
    )
}

export default RideHistory;