import { StyleSheet, Text, View ,Button , TextInput , TouchableOpacity} from 'react-native';
import React, { useState, useEffect } from 'react';
import MapView ,{Marker} from 'react-native-maps';
import * as Location from 'expo-location';

function Destination({navigation , route}) {
    const {pickup} = route.params
    const [location, setLocation] = useState(null);
    const [places, setPlaces] = useState([])
    const [destination, setDestination] = useState()

    useEffect(() => {
          Location.watchPositionAsync({
              accuracy:6,
              distanceInterval:1,
              timeInterval:1000
            },(location)=>{
              // console.log('location',location)
              setLocation(location);
            });
            }, []);

      const searchPlaces = (text) => {
        setDestination()
        const options = {
          method: 'GET',
          headers: {
            accept: 'application/json',
            Authorization: 'fsq3+tAdNKBdJW1kCfIcOMqaB4xfCDuIoeKQpdC57vrDoOs='
          }
        };
  
        const {latitude , longitude } = location.coords
        
        fetch(`https://api.foursquare.com/v3/places/search?query=${text}&ll=${latitude},${longitude}&radius=3000`, options)
          .then(response => response.json())
          .then(response => {
            console.log(response)
          setPlaces(response.results)
        })
          .catch(err => console.error(err));
      }
  
      const onPlaceSelect = (item) =>{
        setDestination(item)
      }

      if(!location){
        return<Text>Loading...</Text>
    }
    return (
        <View>
      
           <View style={styles.searchContainer}>
        <TextInput
          style={styles.input}
          placeholder='Search any location'
          onChangeText={searchPlaces}
        />
      </View>

      <View>
            <Text style={styles.selectedPlaceText1}>Your Selected Pickup location is </Text>
            <Text >{pickup.name}, {pickup.location.address}</Text>
          </View>

      <View style={styles.placesContainer}>
          {!destination && (
            <View>
              {places.map((item, index) => (
                <TouchableOpacity key={index} onPress={() => onPlaceSelect(item)}>
                  <Text style={styles.place}>{item.name}, {item.location.address}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
           </View>
      
          {destination && ( 
            <View style={styles.selectedPlaceContainer}>
              <Text style={styles.selectedPlaceText}>Your Selected destination location is </Text>
              <Text style={styles.selectedPlace}>{destination.name}, {destination.location.address}</Text>
            </View>
          )}
      
      <MapView
  style={styles.map}
  initialRegion={{
    latitude: location.coords.latitude,
    longitude: location.coords.longitude,
    latitudeDelta: 0.0001,
    longitudeDelta: 0.0001,
  }}
  region={pickup ? {
    latitude: pickup.geocodes.main.latitude,
    longitude: pickup.geocodes.main.longitude,
    latitudeDelta: 0.001,
    longitudeDelta: 0.001,
  } : null}
>
  {/* Marker for user's current location */}
  <Marker
    coordinate={{
      latitude: location.coords.latitude,
      longitude: location.coords.longitude,
    }}
    title={"Your location"}
    description={""}
  />

  {/* Marker for the selected pickup location */}
  {pickup && (
    <Marker
      coordinate={{
        latitude: pickup.geocodes.main.latitude,
        longitude: pickup.geocodes.main.longitude,
      }}
      title={pickup.name}
      description={pickup.location.address}
    />
  )}
</MapView>
          <View style={styles.buttonContainer}>
      <TouchableOpacity
        style={styles.button}
        disabled={!destination}
        onPress={() => navigation.navigate("Car", { pickup, destination })}
      >
        <Text style={styles.buttonText}>Choose Car</Text>
      </TouchableOpacity>
        </View>
        </View>
      );
      
}
const styles = StyleSheet.create({
    container: {
      flex: 1,
    },
    map: {
      marginTop: '3%',
      width: '100%',
      height: '63%',
    },
    input: {
      height: 40,
      width: 300,
      borderColor: 'rgb(191, 184, 188)',
      borderWidth: 1,
      borderRadius: 5,
      paddingHorizontal: 10,
      marginTop: 20,
      marginLeft: 32,
      backgroundColor: 'rgb(235, 237, 235)',
    },
    placesContainer: {
      marginTop: 20,
      paddingHorizontal: 10,
    },
    place: {
      paddingVertical: 10,
      borderBottomWidth: 1,
      borderBottomColor: 'rgb(191, 184, 188)',
    },
    selectedPlaceContainer: {
      marginTop: -13,
      marginLeft:8,
      paddingHorizontal: 1,
    },
    selectedPlaceText1: {
      marginTop: 3,
      marginLeft:9,
      fontWeight: 'bold',
    },
    selectedPlaceText: {
      fontWeight: 'bold',
    },
    selectedPlace: {
      marginTop: 3,
    },
    buttonContainer: {
      width: '100%',
      alignItems: 'center',
      marginTop: 15,
    },
    button: {
      height: 50,
      width: '70%',
      fontSize: 18,
      fontWeight: 'bold',
      backgroundColor: 'rgb(240, 150, 220)',
      color: 'white',
      borderRadius: 10,
      justifyContent: "center",
      alignItems: 'center',
    },
  })


export default Destination;