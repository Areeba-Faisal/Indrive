import { StyleSheet, Text, View } from 'react-native';

function RideHistoryDetail() {
    return(
        <View>
            <Text>Ride History Detail</Text>
        </View>
    )
}

export default RideHistoryDetail;