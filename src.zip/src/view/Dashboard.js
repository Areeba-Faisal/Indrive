import React, { useEffect, useRef } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Animated, Image } from 'react-native';
function Dashboard({ navigation }) {

    const animatedValue1 = useRef(new Animated.Value(-100)).current;
    const animatedValue2 = useRef(new Animated.Value(-100)).current;
    const animatedValue3 = useRef(new Animated.Value(-100)).current;

    useEffect(() => {
        Animated.parallel([
            Animated.timing(animatedValue1, {
                toValue: 0,
                duration: 1000,
                useNativeDriver: true
            }),
            Animated.timing(animatedValue2, {
                toValue: 0,
                duration: 1000,
                useNativeDriver: true
            }),
            Animated.timing(animatedValue3, {
                toValue: 0,
                duration: 1000,
                useNativeDriver: true
            })
        ]).start();
    }, []);

    return (
        <View style={styles.container}>
            <View style={[styles.buttonContainer]}>
                <View >
                    <Image style={styles.image} source={{ uri: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTEhMVFRUXFhgZFhcYGBcbGRsYGhYXGhYZFxcYHSggGB0lHRYWITEhJSkrLi4uFyAzODMtNygtLisBCgoKDg0OGxAQGysmICYtLS0vLy0tLS0tLS0vLS0tLS0tLS0rLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLy0tLf/AABEIALYBFQMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAAAwQFBgcCAQj/xABKEAABAwEEBQYKBgkDBAMAAAABAAIDEQQSITEFBkFRcRMiYYGRoQcVMlJTkrHB0dIWQlST4fAUFyMkM2JygtSUstOiwuPxc4Oj/8QAGwEAAQUBAQAAAAAAAAAAAAAAAAECAwQFBgf/xAA7EQABBAADBAkCAwcEAwAAAAABAAIDEQQhMQUSQVETImFxgZGh0fCxwRQVUgYjQmOS4fEyU6LSYnLC/9oADAMBAAIRAxEAPwDcUIQhCEIQhCEJrbLbHEKyPDQcBXbwGZS0UrXAOaQ4HIg1B4FJYukJRCEJUIQhCEIQhCEIQkXWho214Y9tMlxyzjkKcc+wfFBNapaKcpN8oGZ6tvYkCCcyT0ZDu96GtAyFEwvCduLt0+4duH4rklxzPZh+KEJheU4NC45Ju6p3nE9pxXvJjOgB3jA9oXSE2zzS0hrnDI16D8f/AGlBMNuHHLtSaE8SFNLQnSE0aKeSaezsVZ1m0vaiTDZ4ZBsdKGuNcv4Zphx7N6swRmZ2631ypRu6uZUHpS12580jmOmDL7gwNq0XQ43cARspicU41X0raGWpkc7pC2QFtHknGhLSK9IphvURY9CSONX80dOLuobOtLt1YjFpbO17wGgG6Hu/iNILXVrl/LlgOkK7PioogYyWOFV1WURll1t9wJvkB35KaPCySZ5jvP2oFaqhIWVxLGl3lFoJ2Y0xw2JdZyhQhCEIQhCEIQhCEIQhCEIQhCEIQhCEIWdawWoyWiQk4NcWNG4NNDTiQSpDU633ZDETzX4t6HDdxFewb1E6cZctEoxPPqd/O53/AHJpYZiwte3Nrqj+04exc70pjxBkP6jfnR9PoqW9uyWea1ZCai01ALQSCKgnAY96C9x204fEroS4BX90pw5wGZokTONgJ9nafckwwZ7d5xPaV0mGTkl3Eco47m957/guSyudTx+GS6QmF5KcAAgIQhNSoQhCEIQhCEIQhCEIQhCEIXq8QhCrGkIDG6lK1xBwHtKbRWoMlYAKu8sjoBzPE4du5Wu0QNcOeAQO7rVB0jpZpa97AA5znMbQZMaTdx4GvFxUkOHfK6mDiB58T2UCfBWxim7tP5G+3++a0az2pjwHNcCCKjpG/gl1TNRw/kQ0guaSXAH6oywrsJBPWrSHOGRr0H45+1PdJH0j2NN7ri264g0fbKxdhUNw0CeItOkJFs424eztSycmoQhCEIQhCEIQhCEIQq9FrZZzKYyXNoSA9wFwkGmBBqB0kAKwprXtd/pNoQmdv0hHC29I6lchmSegBPFS9d68rHnS4abq3saf9PcosTKYoy8D5dJr3brSVH6etzJpeUjBGABvUxIrQihOynYomMULh017fxBXRfQ44bjs/BcPNHCgrUU6xl7Sude8vcXO1KoONm1MWXT8zLoDgWtAAaQMhhmMVc7HaRIxr25OFeG8dRwWbsZTpJzP52K6apPrBTc9w9h96vYKVxeWE2K9vsrWGeS7dJU0hCFpK6hCEIQhCEIQhCEIQhCEIQhCEIQhe0TPSlvZZ4nSyHmt3Zk7AFnFs1mlnkEjZKBp5jWHAbcd5yz9iY94Yr2DwL8STRAHM/bj38u+gdSQovQGmG2mOuAe3B7dx3joP4KVTwQRYVSSN0byx4ohMtKzUbdGbvYqxPo5kjAzJrXClNwFCO84qWt0t553DAfntTaPLjU9pquXxO0JW4h0sTiN0gCuze61aXrRI0NK4yFu4GuGuvzy8lPaEhDYhQUr7BgB3JzaDShORPfs+HYurK2jGj+UexeWyK8xzejDiMQuljidHhmsbqG+Zq8+86ntvVZ7nAyEnmvFy0U8k09nYm2j7RfbjmM/cU6SQTNljEjND89ND2p72kEtK6bMdo6x8P8A2lmuBxGKbrwYGoz9vFWRJzURbyTtC4jfUVXakTEIQhCFkOmLEYJXxkYNdzelpxb3U66qy6o6yBo5Gd3NA/ZvOwAeS4nZu7NyktdtHxuh5Vzg17PJJ+ttuYZ7abuFVnlKcFiv3sNNbdD9OR+fdVjcbrC1bRum4JyWxPq4CtCC003ioxTTWux8pGC0Vcyrv7do9/8Aas5slodG9sjDRzXVaeHuIwI2glano+1CVjZR9cV4bKdWPerUc4xEbmP1+ZjuUrCJAQVnSTcylKZVy44Ydqk9NwsZM9seVctgO0DoH4bFHyjmnh37FiuaWuLSqRFGl2rlqmylnrve4+we5UwFWTQuno42Nie0tA+tmMSTUjMZ9KsYN7WSW41l7KbDua19uKtCF41wIqDUHEFVrSGv2j4XljrQC4YG4x7wDtF5jSK9a2gCdFpAE6KzIVP/AFmaN9M/7mb5EfrM0b6Z/wBzN8iduO5FLuO5FXBCq9i8IOjpXBjbRdJyvskYPWe0AdqtAKaQRqkII1QhCEiRCEIQhCEIQhIW2yMljdG8Va4UPuI6QcVllu0Q+zucyhLWuIvCtDU1r0Z5bDgtbCqukLOWFzXAkGvWCo5GBy09nYp0JIGY5e3355clXtAWeZjmzMcG9Brzm7QQNh/FX5mkGuY5wwIGR37OIqqVoO13gISDfFQBQ1IFd20e5T2i23p2xuH1HucDuFG47sXgj+kpjGndIjOdeFqfaQLnkyCq9R9+/hmuXGgquWCgA6Pcpi1aGBBuGlRkfcVHWizuZg4U9nauSxWCnw0ZD25cxmMhln4nWj2KCOVjzkfdWeMUA4BdoQu+rdKxlW4ZeTlO6pB4KbKgtID9q9SthkvMB25HqXNbKl3ZJIOAJI8DR+x8ytDECwH/ADRLoQhbaqrqE48U4TZuY4pypmHJRuGaEIQnpqqHhBsziyN4qWsLg7ovXaE9hHWqMa9C2SRgIIIBBFCDkQcwQqLrFqmYw6WEjkwC5zDm0DE3T9YdGfFZmMwziekbnz+fPFQSxkneCqjdys2rmnhDC+N1S6pMYpXMbdwBFetVohK2U84fnYs5kjozvNUDXFpsJ9XaV4vHOolbPA5/kivTs7VWJAGaY1pcaaLSEOQ6MOzD3L1j65Zb9/Do6U88TSVNbtK1pjuGaV8VSfy96i/Ew/rHmrH4Of8AQUw1o06+LRb2NcQ58rYgRmGOa57gOpjxwKz/AFOuG1RRPiikZI8NcJGB1AK+TXySfgrvrPqzaJ4mRx8nhJfN5zhk1zRSjT5xUBZNRbfG9skboWvaatN92BHQY6Lfwe08I2BrXStB7/ALWw0TxDuuFH5S41dsMdoic+RlnZJaCYoW4R3SyG9fhYMC4yvhaei9vSFisERsbLcYv4TTG6IglkslQI5jU/wxfo/ZeYB9Y0ew6laQZyV18I5F16Lnu5rrwdUfs8cWtONckqNUdJ1vcrDXkuR8o05KlCy7ydKbcs8c8VZ/NcD/ALrfNTdG68vnwUqvpqBreQugC9ZYHuptc5lXE9JK1nwP6VdLY3RPNTA+60nPky0Fo6jeA6AFRZ9Q7e+7edCbrGsbz3YNaKNGEewK2+DXQs9hfOZ7hZI1lLjnON5hdmC0bHnsTZNqYJzaErfNNfE7cpaQhNPGLP5uz8UeMWfzdn4qt+Y4T/db/UFB0Mn6SnaEhBa2ONAcdxwS6sxyMkbvMII5jNMIINFCEIT0iEUqhCEKo+Dhr5f0q1vFBNO4QVFKQtNG3dwOR3ltU41H0dNytrtlpa5kloloxjs2wx1EdR9UmuX8oO1Whj6KLtlte2U3ThQYHLLcm4jGx4dgc4ZE1l3E+OieGvlcQOXoKy+inFw5oIocR0pnZdJMfhkenLqKfqeOVkzN5hBHZn87lA5paaOSEISckgaCTkFJYGZTVXbeayP/AKvwTzQ78HDgfz3KMe6pJO0ryS2mJj3DMijeJIoerEriMHOBjBJwJd62tacbsJvgPopefS8LH3HSAO250HEgUCfVWZEq4apWkuiLD9Q0HA4gdtV0OHxZkfukd3z7rGhxBe7dIU4nSalOG5BaUameukIQpExCYaaZegkYM3McB1tKfpq41cTuwHv7/YmuNBKBZWQhANCDuUxrNogwSkgfs3klp3bS3op7FD04rnHMLTunUKgQWmipEGuSjNfdLOs8cdnhcWOeC+RzTR1MqAjEXjXHPmdKlNBMvSBpxA53Zs7aLPNa9I8vapZAatvXWf0twFOOJ/uT8BhxNigHCw0bx79G/c8ss1pbPj3WueeOQ+/so02h/nu9Y/FHLv8APd6xSQCfDRj97e/4LqgCVohpOgTbl3+e71ijl3+e71inXit3nDvTe1WUspXEHalopSwgWQuf0h/nu9Yo5d/nu9YpJCRNSvLv893rFHLv893rFJtFTQZlPhox+9vf8ECylDSdAmvLv893rFHLv893rFOhot3nDvTe1WYsIrjXalopSwgWQrPqHrHJFaGxSSOMUhui8Sbr/qFpOVThTLGuxbnZprzQe3jtXy+t41A05+kQMcTzjzX/APyNz7RQ9YWPiWCDENlGTX9V3/tq0+ObT4XmbUUrd5vcrahCFMqiEIQhC9UFpD+I7q9gXWsmnm2ZtBR0rhzW7APOd0dG1Z1abfJI4ue9xJNTiadmQUkmwpdowjrbgu7Iu8iNLGWevlfAbihC7S1eS4bSEtBpXk8BIym4ltPbgs4JQnYf9juhdvDEuB7GAf8A2b7jkh+0N4UWDz/stVj1ji+s5g4PZ7ym9v00x4utc2m3nNr3FZkhaM37POliMZnOep3RZ8iB5BQNxLWu3gwea0IFNNLfw3cR7VSo5XNPNJB6DQ9yU1f0nbXB0VqY4toC17hRwIPkkjyh054Zrk9o/s47Z5a8Sh3GiN00K06zgdezxVp2NbLC8EUaPHmD4+ikg7E8QB2V957Fa9TG82U9LR2A/FVOFubt5NOFfwCvOq0QbAMRVxLiK47h3AJuCbcw7AVmYcfvFLpePIcEilosltx6q89doQhSqNJymgJG5INFBRK2jyesf7guFHIU9iidZdJWaCAvtZAiJDaULiXGpAaBjXAnooSsrn0/ZXztjs/LXXuDQZA0AFxAbiHE0qRiQKLS9dNWxb7OITIYy14e11LwqA5tC2oqKOO3csx0h4KrawExvhlAHnOYexwp3qMwwyj95rz0pSdFE8dfVWG2xPstmnLhclcLja0NCRQHDiT1LNBop3nDvWg602aYthga2WURsF59HOLnUugl2NTQE/3KveKp/Qy/dSfBRbIbE2EyFwt5JzIuhk0HwF+K0oYGMYG8lCWXR5a4OJBp7U/TzxVP6GX7qT4I8VT+hl+6k+C1hLENHN8wp2hrdEzSNqgvtp2cVJeKp/Qy/dSfBHiqf0Mv3UnwR00X6m+Y90poilXvFbvOHejxW7zh3qw+Kp/Qy/dSfBHiqf0Mv3UnwSdJD+oeYUfRs+FQlksBa68SDTLinye+Kp/Qy/dSfBHiqf0Mv3UnwSiaIfxN8x7p7Q1ooJkkbXBfbTbmCpPxVP6GX7qT4I8VT+hl+6k+COmi/U3zHulNEUq94rd5w71a/B7aHWecsc4XJaU6JPqnrxHYmviqf0Mv3UnwXTdF2gYiCYEZHk5M9mxV8THBiInROeMxrYyPA94Oaj3GLXtNafis1mNpkqWigutoXFxNA0VIGfcq9o7woWGQhr+VhJIHPYC2pNMXMJoOk0UFrJoW06Qhs5jq14PPikcWNrShfdO2owwrRyQ0Z4I5atNotEbQCC5sYc4kbQHOugcaFU8HI2WEOeesMnVzGR89R2EKg6NjTRK1xMtL6QbBE6R2NMhvcch+dlU8CoGvukL8ohB5sYqf63D3CnaVdwWH6eYMOmp7v80FUkduttV22Wp0r3SPNXONSfcNwGSRQhdgAAKCoIQvdnX+favEIQhCUghL3BrRUmvcCSeoAnqSEgCzohK2KIk13b96fiTAndmNy9iaGgALmduHTgOomlO9eabUx/43EGT+EZN7vcnM8tOCiJsrqMUAHQF22oNRgd4z7Ulfr5OW/wCG/wBi7a2izSkV41btzpYueauabpO/AEE9OPcpqDI8fcFBar2e7ACc3ku6sh7K9afaQ0nHZ2l8hz8lo8pxxwA/IC6HDuIjBeeC0mX0YtSiFXdEa1RzX7zTHdpTGtQa9GGXehTtlY4WCkBBzCn3tqCEgE6TeVtDXfnx2fngleLCe0rxRGkrVU3RkM+kp9b57rDTM4BQa53bGLLR0DTrme7gPHj2ZaFX8NHfWK5Lsad/TuXqCK5rhppgeo+49K5ygrq7QvUIoIXiF6hFBC8QvUIoIXiF6hFBC8QvUIoIXiCV6kxzuGzp6eCKCVdMdX3KU0dbfqOPA+4qNQrGGxL8M/fZ4jgRy9uSjkjDxRVlWPW+08pK+Q/Wc53UTh3UWnzWv92kftbG+vENP4LKQvU9gFsjHTN0IFepP2WFirBDShCF1FGXODRmSAOJNFvqqlZbI5sbJCKNeXXem7QE9vsSCvOvFhDbNFdGETg3qLae1oVGVbB4jp4uk7T9TXpSe9u6aQrLqFZg+aSuyJwH9xAJ7KjrVaUnq9pN0Et5tDeaW41piQQcDvHem4+/w0lcifAZn0tIwgOBKcUpgdiTlbWgO/2A/glpX3nFxzJJNMsTXBJHyuA9pHwK8sGSrpROdF2IzSBgyzcdzRmfd1psupbY9sZYzmhx57h5RFMG12DPtT4w3e62nzLxStq81oFstTIIi92DWigA7A0exZppTSL55C9/UNjW7APzim/Kuu3am7Wt2uFcq03pbRmj3zyNjZ5RzOxo2k9A/OauSzOmIaB4dqsSSGSgFN6q6AbaGvfI2rQQG5543siP5UK9WCxNijbG3Jopx3k9JNT1oWlHhI2tAdqpmxtAzTtcubUUXSFbT1X9LSc4N80Y8T+FE6ibE2C/LdDWtLnuOwCpJJ2UAUdbnVkef5iOzD3JvpCHl7JPZS65yrHBrjk1xyvU+rUCvWuWgxEX5hJ0tUSW55gZgC+wgd3NaT43dE0DhR9/qoCy68WGacRMMsYc66x8jQGEk0GIN5oO8jjRWW02RzfLbhv2d2SyfRng6t0kwjkiEcd4X5b7C27XEsLTVxplhxorVrVFpbxo02czcjej5K648iGUbf5UVunG9W9jSlNi1cRsPDS5xdXuzHldeAIQJi00Dff7qygkZ49I94UJp3W6zWVwZIXlxFaNbkDlW8RStCrjpmNgukYE1rw3kLDrRNLabVLaY2zuaXkMdDJybgAA1tH3TSrKVAH1lk4PZAdinxSmw0C6NZnQfW+5SiYOYHaK2Hwk2PdN2R/Ouh4RLKWlwZMWggE0joC4OLR5e0Md2FVn953aT/1n/jTtxtAs7RTSNXSuJ/e+cAxjQ3ncn5JMj8N7eC1vyLB9v9X9lH057PMKZ/WTZfRz9kfzrp3hCguh3I2iji4A0jxLbt76+y83tVZu2ndpP/Wf+NO5haOQiw0jW/LX9652UNLx5PEZ03Y70v5Hg+3+pJ07uzzCm2+EGE5We0HqZ8y7k16aCWmyWmrSQRdbgQaEYHeqq6Oc5t0l/qh/xp1pWGVzw+5bv2jGPIbaGgBxbR4pyfnByBsTB8j/AFFHTu7PRT416Gyx2o/2BS2r+sMdqa8sa9jmGj2OHOGdMsNh7Cs9Nkk9Fb/v2f8AGnGrUzrJbGOcySOKb9m7lHBxvHEEloA8qmzIlV8XsXDiBzoQd4Cxmc64eI07aT2TWc1p5BOeA3b+PwTqCyPf5LTTfkE90PEw3iQC4Hu4Kh6oxaX8ZuNpM3I1k5a+48jdo65yIrdHOu0u7K12qjs/YwnjEr35HgNfP2B70kuIIJA4c/snM+vNgimMTzLIGm66SNoMYINDQk3nAbwOFVd52xOg5SO6WlrXMcNoNKEHaCCsTt3g5t0UpiZGHsrRst9gYW7C6pq00zFOFVqlhi5Gyw2Zrr3Jxta52Qc4DGg3Vr3LSxkODwWHcGtFkEDi4332a4ngFGbe5pBvNe2iT93tDd8Lz1hp91Vniv8AaRVkg3xvHaxw96oC2v2MkLsG9p/hd6EA/W1T2i2pAeYQl9HupLGTsew/9QSCF15F5LPWs6bsXLQSR7S03f6hi3vAWTLW9E21s0TJAQatF7HJ1OcDuos81rsIitDi2lyTntIyxPOHUa9oWDsaUsc6B2uviMj85BWZ22A4KHQ1CFvqspazzXhXbtXTM3dQ7q+9RcEpaahSNmfUV3k+3DuovPNs7KODk32D9245f+J/T/15jLUZxkUl144VFEOdTEoCw01RlKZ7ClIJnMcHscWuaagjYV5KOceKn9VdAGdwkeKRNNcfrkbB0bz1cLMbHPcGt1UjQSclf7DIXxsc4Uc5jSRuJAJCE4QujV5CEIQhVK1AlzjXG87HrOBSfKDbhxy7U4tn8R/9TvelrNo8vbeBbntr8FwToJJp3sYLNu+pW2Xta0F2iZco3eO0I5Ru8doXGkLXDBK2GaeFkj6XWk44mgrhRtTgK0qu7dIyF7I5ZYWPf5DHSMa52NBdBIrjhxQdm4gawu/pv6I6dn6vVc8o3eO0KpSeD6wkkh8gGwB8dB0CrSadatukZWwNc+YhjWCridg6s+pQH02sPpx6knyp+F/GR734cPHA7oOo4Ghws5FKd05qP/V3Y/Sy+vF8i6d4P7IQAZpiG1ui/FQVNTTmYYklPvptYfTj1JPlR9NrD6cepJ8qtdLtX+b5O9ktMUf+rux+ll9eL5F27UGyFoaZpbrSSBfiwLrt4+Rtut7E9+m1h9OPUk+VH02sPpx6knyo6Xa383yd7JKYo/8AV3Y/Sy+vF8i7fqBZCGtM0pDQQ0X4sASXEDmbyT1p79NrD6cepJ8q9+mth9OPUk+RHS7V/m+TvZFMUd+rux+ll9eL5ErZNQ7FG9r70rrpBo58dCQait1oJFelPPprYfTj7uX5EfTWwenH3cvyI6XapyqXyeimqfvt3jtC95Ru8doXtjpKGmOjg4AtIpQgioIO6i5sMjJnvjilikezy2tkY4txpzg0mmOCzY8JJLmyMnuaT9kGRrdTXiveUbvHaFzym7H2dq40dbIJ5HRQzxPkZW80OxoDQkGlHAGlSKqStWjyxt4lvVWvsUztnYiNpcYyAMzwTemYTV5prZoqkA43jQnjh2LOy2mBzGC0mxDnt/qCp2ndDyMmkLW3ml7iLuYBJIFDjt2VXY/sdiGRMlDyBZFX2A+6oY+J8jm7oulDoSdrkMbS50coDRU1Y4e2igLVrE4/w2hvS7E9mQ712j8ZA0XvX3Z/2VBuFlP8Nd+StlmtDmhzQ4gOFHAHAjPHevDi2nWB07VUrBpO0PeGto/HEXRSnSRkOlWwHf2rjdpSiDHDEwanrUefHwfr4uUU0LonUUghKTN2pB7wMSaLtoJ2TRCZh6pF/wCe0aHtTBnkF2o6TWJkTubV5208nt29SZ6ZtcjqRxNJDs7oJceigyGIS2hdVXEh1o5rfMBxP9W4dGfBZG0tqQxtMZog63nfYBx79FcEDIxc+XZx+fLVo0bOJY2S0IvCoB2cPinRNF41oAAAoBgB0JC1SbO1efmiTWQWcczkpXVDRsc8zuVBIa29SuBNfrbwtGa0AAAUAyAVL8HcGM0lMKNaD2kj/arut7AtAiB5+5pXYh1UIQhXFIhCEIQq9peAtkLtjsRxpiO6qRslqdGajI5jerG9gIoQCNyy/wALNvnsj7ObM8xte2S8A1pF5pZTF4NMHHAblgz7ImdiOmw7wCTedijxzAOufLWjavwzhzejcF3rXqbFbLV+kGZ8YeGiVlwOJugN5jrwu1aAMQd6S1x1MFttQnZPcY5rGvDmkuaGilWUNDUbDTGpxqqF9Mrd9oPqRfIj6Y277QfUi+RXRHtUfxxf8vs0BTBrBVXl85LZ9YY2TxFjCamMsqag1pzTUEGtdyyjxNbfRy//ALf8640brZbXE3piQB5kW/oYn/0ltXpj6sfypMPhNoxue8GI7xB1fV1WXV45WnshaWiuCZ+KLb6Obsm/yEeKLZ6Ofsl/yFe/B5apLS6bl3Xw1rLuAFCS6vkgbldf0CPze8/FPe/HtNVF5v8AZQP3GO3TfosP8U2z0U/ZL/kI8U2z0U/ZJ/krcP0CPze8/FH6BH5vefim9Lj+Ufm/2TN+Pt9Fh/im2eitHZJ/krzxVbPQ2jsk/wAlbj+gR+b3n4o/QI/N7z8UdLj+Ufm/2Rvx9vosO8VWz0No7H/5K6j0PbHEN5K0CppUh4A6T+85LcBYI/N7z8VkNs1gtTJHs5U817m+THscR5vQpIztB+gi83+ymiayS6taTork42lrjQXAxpFa0pQ478BiqhqVqcLFaTM+e+wMcxga0hxDqCr6nDAZCuPBVa360WxrCWzEGo+pHv8A6VF/TG3faD6kXyKtBgtpYePo2uirPXeJzN67v2T5I22bvOloeqOp0ditPLiZ8oa1zYm3A0gOFKvdeN40wwA3q02q1OkNTlsG5YrHrdpBxDWzuJJoAGRVJP8AYrBo3SOkGva6ecEA1MdxmPQ4hoIHAqtjcJj5hU0jK5C8/wDjn4lSwYcyOuNpJ58voFoLrdHB+0kOArQDNxphQe/Yoyy6ZE73EgMcTUNrXCm/aVWLVaHSOLnmpP5oAMAOgJIFGEjOHj3BnnZ7T/gBazNms3esesePLuHH5VK6TyRNFZwHR1Ae0tvAg7C3apaHVfR5Ac2x2YggEHkmZHEbFnT7RI4ULnEbiSVqOgK/o0Nc+Tb2Uw7qLRikJJGiy9pYPoWNeTndKEt2psQBMJMdATcpVuAyGRHeqUtcmlaxpc8gNAJJOQAzWTWwsD3BhvMqbpoRzdmBxVTFQAEFg7/RYjdnzYh37hl8zwHeTl9+VlcB1CKgEZ0O3ip6x2CzSNDxEyu0HGh3EFVtxXsbyDUEg7waJ0L3xirNcrK6jDbGbDFuh3W4nh3AcB6/QWbScbGxjANAcKACg27B29SYhRb5pHkBznOplUkp46ejRvut/wBoVXFDecHUsTbuAEAZJeZsHwqjz7DzySk0t3imkUTnuDWguc40AGZKcWDR8s7qRtLjtOwcTkFftX9XmWcXnUfKc3bBXY0bOOZ7kuHwrpT2c1hRxF3cnugtGizwtjwJzcd7jn8OACkkIW+1oaKGiugVkhCEJUJvI6SvNawjpeR7GFRds0haYm3nwQ0qBhO8nHjAEIQpGtBKjpdapqc2zxk9M7h3iEqA1qlkt0PJS2aJpDqse20vvNdQCorZ8iDQj30KEJymEbQbCymXRb2uc0ltW1BoTTOmGC88Wv3t7T8F4hSKxad2aF0fNo01zN4/KleUf5rfWPyoQnBxSiV4GRVn1e1yfZGcnHZmOcTV73Suq48BHgBTAfEpx+uKT7Gz713yIQmmNrjZSmNpJJXh8MEv2SP713yLz9cUv2SP7x3yoQjoWcknRM5I/XFL9kj+8d8q8Phhl+yx+u74IQjoWckdEzkj9cE32WL13fBVPTOs/LyvlEDYycXAOJBdtcKjCu1CEBoYeqlDQzNqYP0pUEFgoekpjVCE4m0pcXapzoy3uglZKyl5hqK5biD1Eq1zeERx8qywu4kn2hCFBJgMPiXB0rbIyvMGr7CErXEHJNptdmOONjYP6Xub20CUg14aw82xsrvdIXdxbgvEI/L8NXRbuXeb153fqphPKW1vnzKdjwlv+zM9c/BPYvC/I0BosjMB6R3yoQki2ZhcObiZRI5n7lQOG/8A6l2/wsSvFw2SPHbyruPmJvLrc53lWOzn+4+3k0ISS7Nw01Pe3OtbI+hSAmMdQ0m79PgmpsjB0MmcB3xFKw6zhhq2xsqPOmLuysWCEJDs/DlpiLcu83x43fqpDiZi3N58zXknP06l2WeMf/Y75ElZtZow4mWxiQkkn9uQKk1wbyWXGq9Qmx7KwkWbGD1P1KrvaJa386Vu0Prw+VpENkja1ppQzlvYGwlSX0qtH2WH/Uv/AMdCFOWgZKJ8TQdERa1zfXs8Y3XZ3O9sIUtZ7ZantDhBBQ5VnfXrpAhCaUx0baT6N01BeZGDtAkcR1G4PYhCEihX/9k=' }} />
                </View>
                <Animated.View style={[styles.fare, { transform: [{ translateX: animatedValue1 }] }]}>
                <Text style={styles.text}>Fare Estimation</Text>
            </Animated.View>
            <Animated.View style={[styles.tracking, { transform: [{ translateX: animatedValue2 }] }]}>
                <Text style={styles.text}>Real Time Tracking</Text>
            </Animated.View>
            <Animated.View style={[styles.review, { transform: [{ translateX: animatedValue3 }] }]}>
                <Text style={styles.text}>Rating & Reviews</Text>
            </Animated.View>
                <TouchableOpacity
                    style={styles.button}
                    onPress={() => {
                        navigation.navigate('Pickup');
                    }}
                >
                    <Text style={styles.buttonText}>Go to Pickup</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
    }
const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#333',
        marginBottom: 20,
    },
    buttonContainer: {
        width: '80%',
        alignItems: 'center',
    },
    image: {
        marginTop: -80,
        width: 310, // Adjust width as needed
        height: 200, // Adjust height as needed
        marginBottom: 60, // Adjust margin as needed
    },
    button: {
        backgroundColor: 'rgb(240, 150, 220)',
        paddingVertical: 15,
        borderRadius: 10,
        width: '100%',
        alignItems: 'center',
        marginTop: 6,
    },
    buttonText: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#fff',
    },
    car: {
        backgroundColor: 'transparent',
    },
    fare: {
        backgroundColor:"rgb(240, 193, 62)",
        width: "100%" ,
        padding: 20,
        borderRadius: 10,
        marginTop: -20,
        marginBottom:12,
       
    },
    tracking: {
        backgroundColor:"rgb(240, 193, 62)",
        width: "100%" ,
        padding: 20,
        borderRadius: 10,
        marginBottom:12,
        // marginTop: 20,
    },
    review: {
        backgroundColor:"rgb(240, 193, 62)",
        width: "100%" ,
        padding: 20,
        borderRadius: 10,
        marginBottom:12,
    },
    text: {
        fontSize: 18,
        fontWeight: 'bold',
        marginLeft: 10,
        fontSize: 20,
    },
});

export default Dashboard;

